package controller;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;

public class ReceptionLoginFormController {
    public JFXTextField txtUserName;
    public JFXPasswordField passwordPwd;

    int attempts=0;

    public void adminLoginOnAction(ActionEvent actionEvent) {
    }

    public void receptionLoginOnAction(ActionEvent actionEvent) {
        attempts++;
        if(attempts<=3){
            if (txtUserName.getText().equals("reception") && passwordPwd.getText().equals("4321")){
                new Alert(Alert.AlertType. CONFIRMATION, "Success").show();
            }else{
                new Alert(Alert.AlertType.WARNING, "Try Again").show();
            }
        }else{
            txtUserName.setEditable(false);
            passwordPwd.setEditable(false);
        }
    }
}
